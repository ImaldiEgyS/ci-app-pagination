<div class="container">
    
    <h1 class="mt-4">About Me</h1>
    <img src="<?= base_url()?>/about/img/egi.jpg" alt="" width="200" class="rounded-circle">
    <p>Hallo nama saya <?= $data['nama']?>, Saya seorang <?= $data['pekerjaan']?>, umur saya <?= $data['umur']?> tahun</p>
    
    </div>